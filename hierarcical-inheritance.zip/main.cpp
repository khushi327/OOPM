#include<iostream>
using namespace std;
class   Employee
{
    char name[20];
    long id;
    public:
    void getdata()
    {
        cout<<"Employee Name:";
        cin>>name;
        cout<<"Employee ID:";
        cin>>id;
    }
    void putdata()
    {
        cout<<"Employee Name:"<<name<<"\n"<<"Employee ID:"<<id<<endl;
    }
};
class Manager:public Employee
{
    char dept[20];
    double dues;
    Employee::getdata();
    {
        cout<<"Employee Departement:";
        cin>>dept;
        cout<<"Employee Dues:";
        cin>>dues;
    }
    Employee::putdata();
    {
        cout<<"Employee Departement:"<<dept<<"\n"<<"Employee Dues:"<<dues<<endl;
    }
};
class Scientist:public Employee
{
    int publication;
    public:
    Employee::getdata();
    {
       cout<<"Publication:";
        cin>>publication; 
    }
    Employee::putdata();
    {
        cout<<"Publication"<<publication<<endl;
    }
};
int main()
{
    Manager M1;
    Scientist S1;
    cout<<"Enter Manager detail:";
    M1.getdata();
    cout<<"Manager detail:";
    M1.putdata();
    cout<<"Enter scientist detail:";
    S1.getdata();
    cout<<"scientist detail:";
    S1.putdata();
    return 0;
}