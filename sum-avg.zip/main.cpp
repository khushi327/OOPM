#include <iostream>
using namespace std;
int main()
{
    int n,sum=0,avg;
    cout<<"Enter 10 Natural number:";
    for(int i=0;i<=9;i++)
    {
        cin>>n;
        
    }
    
    for(int i=0;i<=9;i++)
    {
        
        sum=sum+n;
    }
    cout<<"sum:"<<sum<<endl;
    avg=sum/10;
    cout<<"average:"<<avg<<endl;
    return 0;
    
}