#include<iostream>
using namespace std;
class Complex
{
    int real,imag;
    public:
    void getdata()
    {
        cout<<"\nEnter real value:";
        cin>>real;
        cout<<"Enter imaginary value:";
        cin>>imag;
    }
    void display()
    {
        cout<<""<<real<<"+"<<""<<imag<<"i"<<endl;
    }
    Complex operator +(Complex c)
    {
        Complex temp;
        temp.real=real+c.real;
        temp.imag=imag+c.imag;
        return temp;
    }
    Complex operator -(Complex c)
    {
        Complex temp;
        temp.real=real-c.real;
        temp.imag=imag+c.imag;
        return temp;
    }
};
int main()
{
    Complex c1,c2,c3;
    cout<<"Enter first complex number:";
    c1.getdata();
    cout<<"Enter second complex number:";
    c2.getdata();
    cout<<"\nAddition:"<<endl;
    c3=c1+c2;
    c3.display();
    cout<<"\nSubtract:"<<endl;
    c3=c1-c2;
    c3.display();
    return 0;
}