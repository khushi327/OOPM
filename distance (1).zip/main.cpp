#include<iostream>
using namespace std;
class Distance
{
    private:
    int feet;
    float inches;
    public:
    void getdata();
    void setdata(int, float);
    void display();
};
 void Distance::getdata()
{
   cout<<"Enter feet:";
   cin>>feet;
   cout<<"Enter inches:";
   cin>>inches;
   
}
void Distance::setdata(int f, float i)
{
   
   feet=f;
   inches=i;
}
void Distance::display()
{
    cout<<"Feet:"<<feet<<endl;
    cout<<"Inches:"<<inches<<endl;
}

int main()
{
    Distance d1;
    d1.setdata(7,12.5);
    d1.display();
    d1.getdata();
    d1.display();
    return 0;
}