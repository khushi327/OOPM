#include<iostream>
using namespace std;
class Time
{
    int hour;
    int minute;
    int second;
    int am_pm;
    public:
    Time()
    {
        hour=2;
        minute=10;
        second=00;
        am_pm=1;
    }
    Time(int h,int m, int s, int a)
    {
        hour=h;
        minute=m;
        second=s;
        am_pm=a;
    }
    void display()
    {
        if(am_pm==0)
        {
            cout<<hour<<":"<<minute<<":"<<second<<"am"<<endl;
        }
        else
        {
            cout<<hour<<":"<<minute<<":"<<second<<"pm"<<endl;
        }
    }
    void convertTo12()
    {
        if(hour>=12)
        {
            hour-=12;
        }
    }
    void convertTo24()
    {
        if(am_pm==0 && hour==12)
        {
            display();
        }
        else if(am_pm==1 && hour!=12)
        {
            hour+=12;
        }
    }
};
int main()
{
    int hr;
    int min;
    int sec;
    int A;
    cout<<"Enter time and also press 0 for AM and 1 for PM:";
    cin>>hr;
    cin>>min;
    cin>>sec;
    cout<<"press 0 for AM and 1 for PM:";
    cin>>A;
    Time T1,T2(hr,min,sec,A);
    T1.display();
    T2.convertTo12();
    T2.display();
    T2.convertTo24();
    T2.display();
    return 0;
}