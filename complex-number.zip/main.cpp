#include<iostream>
using namespace std;
class Complex
{
    private:
    int real;
    int imag;
    public:
    void getdata()
    {
        cout<<"\nEnter real value of complex number:";
        cin>>real;
        cout<<"Enter imaginary value of complex number:";
        cin>>imag;
    }
    void display()
    {
        cout<<""<<real<<"+"<<""<<imag<<"i"<<endl;
    }
    Complex add(Complex C){
        Complex temp;
        temp.real=real+C.real;
        temp.imag=imag+C.imag;
        return temp;
    }
    Complex subtract(Complex C){
        Complex temp;
        temp.real=real-C.real;
        temp.imag=imag-C.imag;
        return temp;
    }
    Complex multiply(Complex C){
        Complex temp;
        temp.real=(real*C.real)-(imag*C.imag);
        temp.imag=(imag*C.real)+(C.imag*real);
        return temp;
    }
    Complex divide(Complex C){
        Complex temp;
        int denominator=(C.real*C.real)+(C.imag*C.imag);
        temp.real=(real*C.real)+(imag*C.imag)/denominator;
        temp.imag=(imag*C.real)-(C.imag*real)/denominator;
        return temp;
    }
};
int main()
{
    Complex c1,c2,c3; 
    cout<<"Enter first complex number:";
    c1.getdata();
    cout<<"Enter second complex number:\n";
    c2.getdata();
    cout<<"Addition:\n";
    c3=c1.add(c2);
    c3.display();
    cout<<"subtraction:\n";
    c3=c1.subtract(c2);
    c3.display();
    cout<<"Multiplication:\n";
    c3=c1.multiply(c2);
    c3.display();
     cout<<"division:\n";
    c3=c1.divide(c2);
    c3.display();
    return 0;
}