#include<iostream>
using namespace std;
int Area(int s)
{
    return s*s;
}
int Area(int l, int b)
{
    return l*b;
}
double Area(double r)
{
    return 3.14*r*r;
}
int main()
{
    cout<<"Area of square:"<<Area(5)<<endl;
    cout<<"Area of rectangle:"<<Area(4,4)<<endl;
    cout<<"Area of square:"<<Area(2.3)<<endl;
    return 0;
}