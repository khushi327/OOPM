#include<iostream>
using namespace std;
void swap(int a, int b)
{
    int temp;
    temp=a;
    a=b;
    b=temp;
    cout<<"After swaping:"<<endl;
    cout<<"1st number:"<<a<<endl;
    cout<<"2nd number:"<<b<<endl;
}
int main()
{
    int a,b;
    cout<<"Enter one number:";
    cin>>a;
    cout<<"Enter second number:";
    cin>>b;
    cout<<"Before swaping:"<<endl;
    cout<<"1st number:"<<a<<endl;
    cout<<"2nd number:"<<b<<endl;
    swap(a,b);
    return 0;
}