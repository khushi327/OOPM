#include<iostream>
using namespace std;
int main()
{
    int score;
    cout<<"Enter your score:";
    cin>>score;
    if(score<0|score>100)
    {
        cout<<"Invalid score! please Enter between [0-100]"<<endl;
    }
    switch(score/10)
    {
        
        case 9:
        cout<<"Grade A"<<endl;
        break;
        case 8:
        cout<<"Grade B"<<endl;
        break;
        case 7:
        cout<<"Grade C"<<endl;
        break;
        case 6:
        cout<<"Grade D"<<endl;
        break;
        case 5:
        cout<<"Grade E"<<endl;
        break;
        default:
        cout<<"Grade:F"<<endl;
        break;
    }
    return 0;
}