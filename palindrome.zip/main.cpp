#include<iostream>
using namespace std;
void palindrome(int n){
    int sum=0;
    int digit;
    int orignal=n;
    while(n>0)
    {
        digit=n%10;
        sum=sum*10+digit;
        n=n/10;
    }
    
    if(sum==orignal)
    {
        cout<<"no. is palindrome"<<endl;
    }
    else
    {
        cout<<"no. is not palindrome"<<endl;
    }
}
int main()
{
    int n;
    cout<<"Enter the number:";
    cin>>n;
    palindrome(n);

    return 0;
}