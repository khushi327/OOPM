#include<iostream>
using namespace std;
void swap(int &c, int &d)
{
    int temp;
    temp=c;
    c=d;
    d=temp;
}
int main()
{
    int a,b;
    cout<<"Enter 1st number:";
    cin>>a;
    cout<<"Enter 2nd number:";
    cin>>b;
    cout<<"Before swap:"<<endl;
    cout<<"1st element:"<<a<<endl;
    cout<<"2nd element:"<<b<<endl;
    swap(a,b);
    cout<<"After swap:"<<endl;
    cout<<"1st element:"<<a<<endl;
    cout<<"2nd element:"<<b<<endl;
    return 0;
}