#include<iostream>
using namespace std;
int maximum(int *a)
{
    int maxVal;
    maxVal=a[0];
    for(int i=0;i<10;i++)
    if(maxVal<a[i])
    {
        maxVal=a[i];
    }
    return maxVal;
};
int minimum(int *a)
{
    int minVal;
    minVal=a[0];
    for(int i=0;i<10;i++)
    if(minVal>a[i])
    {
        minVal=a[i];
    }
    return minVal;
};
int sum(int *a)
{
    int sum=0;
    for(int i=0;i<10;i++)
    {
        sum=sum+a[i];
    }
    return sum;
};
float avg(int *a)
{
    int sum=0;
    float avge;
    for(int i=0;i<10;i++)
    {
        sum=sum+a[i];
    }
    avge=sum*1.0/10;
    return avge;
};
int main()
{
    int a[10],choice,maxi,mini,sumi;
    float aveg;
    cout<<"Enter 10 Element:";
    for(int i=0;i<10;i++)
    {
        cin>>a[i];
    }
    do{
        cout<<"Maximum number(1)\n";
        cout<<"Minimum number(2)\n";
        cout<<"Sum(3)\n";
        cout<<"Average(4)\n";
        cout<<"Enter your choice:"<<endl;
        cin>>choice;
        switch(choice)
        {
            case 1:
                maxi=maximum(a);
                cout<<"Maximum number:"<<maxi<<endl;
                break;
            case 2:
                mini=minimum(a);
                cout<<"Minimum number:"<<mini<<endl;
                break;
            case 3:
                sumi=sum(a);
                cout<<"Sum:"<<sumi<<endl;
                break;
            case 4:
                aveg=avg(a);
                cout<<"Average number:"<<aveg<<endl;
                break;
            default:
                {
                    cout<<"Please Enter valid number";
                }
        }
    }    
    while(choice != 4);
    
       return 0;
}