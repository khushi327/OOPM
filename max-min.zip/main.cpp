#include<iostream>
using namespace std;
int main()
{
    int a[10],i,n;
    cout<<"Enter 10 number :";
    for(i=0;i<10;i++)
    {
        cin>>n;
        a[i]=n;
    }
    int max=a[0];
    int min=a[0];
    for(i=0;i<10;i++)
    {
        if(max<a[i])
        {
            max=a[i];
        }
    }
    for(i=0;i<10;i++)
    {
        if(min>a[i])
        {
            min=a[i];
        }
    }
    cout<<"maximum element:"<<max<<endl;
    cout<<"minimum element:"<<min<<endl;
    return 0;
}