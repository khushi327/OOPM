#include<stdio.h>
int fact(int n)
{
    int f=1;
    while(n>1)
    {
        f=f*n;
        n--;
    }
    return f;
}
int main()
{
    int n,a;
    printf("Enter a number to calculate the factorial:");
    scanf("%d",&n);
    a=fact(n);
    printf("factorial of number %d is %d",n,a);
    return 0;
}