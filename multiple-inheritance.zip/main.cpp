#include<iostream>
using namespace std;
 class Academic_marks
 {
     protected:
     int marks_math;
     int marks_phy;
     int marks_chem;
     public:
     void getmarks()
     {
         cout<<"Maths marks:";
         cin>>marks_math;
         cout<<"Physics marks:";
         cin>>marks_phy;
         cout<<"Maths Chemistry:";
         cin>>marks_chem;
     }
 };
 class Sports
 {
     protected:
     int sp_marks;
     public:
     void getsports()
     {
        cout<<"Sports marks:";
         cin>>sp_marks; 
     }
 };
 class Result :public Academic_marks,public Sports
 {
     int total_marks;
     float avg_marks;
     public:
     void Calculate()
     {
        total_marks=marks_math+marks_phy+marks_chem+sp_marks; 
        avg_marks=(total_marks/4.0);
     }
     void display()
     {
         cout<<"Total marks:"<<total_marks<<"\n"<<"Average marks:"<<avg_marks<<endl;
     }
 };
 int main()
 {
     Result r;
     r.getmarks();
     r.getsports();
     r.Calculate();
     r.display();
     return 0;
 }