#include<iostream>
using namespace std;
void swap(int *a, int *b)
{
    int temp;
    temp=*a;
    *a=*b;
    *b=temp;
}
int main()
{
    int a,b;
    cout<<"Enter 1st number:";
    cin>>a;
    cout<<"Enter 2nd number:";
    cin>>b;
    cout<<"Before swaping:"<<endl;
    cout<<"1st number:"<<a<<endl;
    cout<<"2nd number:"<<b<<endl;
    swap(&a,&b);
    cout<<"After swaping:"<<endl;
    cout<<"1st number:"<<a<<endl;
    cout<<"2nd number:"<<b<<endl;
}