#include<iostream>
using namespace std;
int main()
{
    int a[10],key,i,n,f;
    cout<<"Enter 10 element:";
    for(i=0;i<10;i++)
    {
        cin>>n;
        a[i]=n;
    }
    cout<<"Enter number to find:";
    cin>>key;
    for(i=0;i<10;i++)
    {
        if(a[i]==key)
        {
            f=1;
        }
    }
    if(f==1)
    {
        cout<<"element is found"<<endl;
    }
    else
    {
        cout<<"element is not found"<<endl;
    }
    return 0;
}