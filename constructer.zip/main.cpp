#include<iostream>
using namespace std;
class Date
{
    int date;
    int month;
    int year;
    public:
    Date()
    {
        date=21;
        month=12;
        year=2025;
    }
    Date(int d, int m, int y)
    {
        date=d;
        month=m;
        year=y;
    }
    void display()
    {
        cout<<""<<date<<":"<<""<<month<<":"<<""<<year<<endl;
    }
};
int main()
{
    Date d1;
    d1.display();
    Date d2(25,12,2025);
    d2.display();
    return 0;
}